# Introduction 


# Folder structure


** Please follow the same naming convention in case any new folders are created and add it to this file. **

# Build and Test
All the codes run on Python 3.5.

# Contribute
You can add to this project by creating a different branch and push the resources on it if you think you have substantial changes to the existing code.

If you want to learn more about creating good readme files then refer the following [guidelines](https://www.visualstudio.com/en-us/docs/git/create-a-readme). You can also seek inspiration from the below readme files:
- [ASP.NET Core](https://github.com/aspnet/Home)
- [Visual Studio Code](https://github.com/Microsoft/vscode)
- [Chakra Core](https://github.com/Microsoft/ChakraCore)